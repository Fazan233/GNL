/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vuslysty <vuslysty@student.unit.ua>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/11/12 20:44:34 by vuslysty          #+#    #+#             */
/*   Updated: 2018/11/12 20:51:58 by vuslysty         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include "get_next_line.h"
#include <stdio.h>

int main()
{
	int fd;
	char *str;

	fd = open("test1", O_RDONLY);
	int i = get_next_line(fd, &str);
	ft_putstr(str);
    ft_putchar('\n');
    i = get_next_line(fd, &str);
    ft_putstr(str);
	return (0);
}
